import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

/**
 * Author: Aaron Ramshaw
 * COMP2911 14s1 Assignment 2
 * Pen Plotter
 */
public class PenPlotter {

    public static void main(String args[]) {
        Scanner sc = null;
        InputReader reader = new InputReader();

        // Read input
        try {
            sc = new Scanner(new FileReader( new File("input1.txt")));
            while( sc.hasNext() ) {
                reader.addLine(sc.nextLine());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            sc.close();
        }

        reader.execute();

    }
}
