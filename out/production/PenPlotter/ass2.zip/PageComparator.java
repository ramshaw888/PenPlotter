import java.util.Comparator;

/**
 * Created by aaron on 7/05/2014.
 */
public class PageComparator implements Comparator<Page> {

    public PageComparator() {}

    @Override
    public int compare(Page a, Page b) {
        double aMove = a.getMove();
        double bMove = b.getMove();

        if( aMove < bMove ) {
            return -1;
        }

        if( aMove > bMove ) {
            return 1;
        }

        else {
            return 0;
        }

    }

}
