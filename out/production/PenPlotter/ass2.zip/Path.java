import java.util.ArrayList;

/**
 * Created by aaron on 10/05/2014.
 */
public class Path {

    public Path() {
      //  this.path = new ArrayList<Point>(1);
        this.toGo = new ArrayList<Line>(1);
        this.g = 0.0;
        this.last = new Line(new Point(0,0),new Point(0,0));
        this.parent = null;
    }

    public Path(Point a, Point b, ArrayList<Line> lines) {
      //  this.path = new ArrayList<Point>(1);
        this.toGo = new ArrayList<Line>(1);
        this.g = 0.0;
      //  path.add(new Point(0, 0));
        // System.out.printf("Path %d %d to %d %d\n", a.getX(),a.getY(),b.getX(),b.getY());
        // System.out.printf("\t\tDist 0,a is %f\n", distance(new Point(0, 0), a));
        g+= distance(new Point(0,0),a);
        //  System.out.printf("\t\tDist a,b is %f\n", distance(a,b) );
        g+= distance(a,b);
        //  System.out.printf("\t\ttotal g is %f\n", g);

     //   path.add(a);
     //   path.add(b);
        toGo = new ArrayList<Line>(1);
        toGo.addAll(lines);
        this.last = new Line(a,b);
        toGo.remove(new Line(a, b));
        this.parent = null;
    }

    public boolean addLine(Point a, Point b, Line l) {

        if( !last.getPointB().equals(b) ) {

            //    System.out.printf("\t\tAdding a,b %f\n", distance(a, b) );
            g+= distance(a,b);
            //    System.out.printf("\t\tAdding last (%d %d), a %f\n", last.getPointB().getX(),last.getPointB().getY(), distance(last.getPointB(), a));
            g+= distance(last.getPointB(), a);
            //    System.out.printf("\t\tTotal g is %f\n",g);
            if( !last.getPointB().equals(a) ) {
          //      path.add(a);
            }
          //  path.add(b);

            if( l != null ) {
                last = new Line( a,b );
                toGo.remove(l);
            }

            return true;
        } else return false;
    }

    /*

    public void printPath() {
        System.out.printf("\t");
        for( Point p: path) {
            System.out.printf(" %d %d,", p.getX(), p.getY());
        }
        System.out.printf("\n\tTOGO ");
        for( Line l : toGo ) {
            System.out.printf("%d %d to %d %d,", l.getPointA().getX(), l.getPointA().getY(), l.getPointB().getX(), l.getPointB().getY());
        }
        System.out.printf("\n");
    }

    */

    public double getG() {
        return g;
    }

    public ArrayList<Line> getToGo() {
        return toGo;
    }

    public Line getLast() {
        return last;
    }

    public Path getParent() {
        return this.parent;
    }

    public void setParent(Path p) {
        this.parent = p;
    }
/*
    public void setPath(ArrayList<Point> path) {

        this.path = new ArrayList<Point>(1);
        this.path.addAll(path);
    }
*/
    public void setToGo(ArrayList<Line> toGo) {
        this.toGo = new ArrayList<Line>(1);
        this.toGo.addAll(toGo);
    }

    public void setG(double g) {
        this.g = g;
    }

    public void setLast(Line last) {
        this.last = last;
    }

    public Path duplicate() {
        Path dupe = new Path();
      //  dupe.setPath(path);
        dupe.setToGo(toGo);
        dupe.setG(g);
        dupe.setLast(last);
        return dupe;
    }
/*
    public ArrayList<Point> getPath() {
        return path;
    }
 */
    public double distance(Point a, Point b) {
        return Math.sqrt( (a.getX()-b.getX())*(a.getX()-b.getX()) + (a.getY()-b.getY())*(a.getY()-b.getY()) );
    }


 //   private ArrayList<Point> path;
    private ArrayList<Line> toGo;
    private Line last;
    private double g;
    private Path parent;
}
