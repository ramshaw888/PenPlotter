/**
 * Created by aaron on 10/05/2014.
 */
public class Line extends Object {

    public Line(Point a, Point b) {
        this.a = a;
        this.b = b;
    }

    public Point getPointA() {
        return a;
    }

    public Point getPointB() {
        return b;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Line line = (Line) o;

        if( line == null ) return false;

        if( line.getPointA().equals(a) && line.getPointB().equals(b) ) return true;
        if( line.getPointA().equals(b) && line.getPointB().equals(a) ) return true;
        return false;

        /*

        if( !line.getPointA().equals(a) && !line.getPointB().equals(b) || !line.getPointA().equals(b) && !line.getPointB().equals(a) ) return false;
        return true;
        */

/*

        if (a != null ? !a.equals(line.a) : line.a != null) return false;
        if (b != null ? !b.equals(line.b) : line.b != null) return false;
*/
    }

    @Override
    public int hashCode() {
        int result = a != null ? a.hashCode() : 0;
        result = 31 * result + (b != null ? b.hashCode() : 0);
        return result;
    }

    private Point a;
    private Point b;

}
