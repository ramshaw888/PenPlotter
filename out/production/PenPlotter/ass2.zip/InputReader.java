import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.PriorityQueue;

/**
 * Created by aaron on 7/05/2014.
 */
public class InputReader {

    public InputReader() {
        result = new Page();
        Comparator<Path> comparator = new PathComparator();
      //  pQueue = new PriorityQueue<Path>(1, comparator);
        allPoints = new ArrayList<Point>(1);
        lines = new ArrayList<Line>(1);
        allPoints.add( new Point(0,0) );
        queue = new PriorityQueue<Path>(1,comparator);


    }

    public void addLine(String line) {

        if( line.startsWith("Line")) {
          //  System.out.println(line);
            String[] inputArray = line.split(" ");
            int x1 = Integer.parseInt(inputArray[2]);
            int y1 = Integer.parseInt(inputArray[3]);
            int x2 = Integer.parseInt(inputArray[5]);
            int y2 = Integer.parseInt(inputArray[6]);

          //  Point start = new Point(0,0);
            Point a = new Point(x1,y1);
            Point b = new Point(x2,y2);

            Line newLine = new Line(a,b);
            lines.add(newLine);


            //Page p1 = new Page(start,a);
           // Page p2 = new Page(start,b);
           // pQueue.add(p1);
          //  pQueue.add(p2);

            result.addPoint(a,b);
            if( !allPoints.contains(a) ) allPoints.add(a);
            if( !allPoints.contains(b) ) allPoints.add(b);
        }
    }

    public void execute() {

        HashMap<Point,Point> parent = new HashMap<Point, Point>(1);

       // HashMap<Path, Line> parent = new HashMap<Path, Line>(1);
        for( Line l: lines ) {
            Path path = new Path(l.getPointA(),l.getPointB(),lines);
            Path init = new Path();
            init.addLine(new Point(0,0),l.getPointA(),null);
            path.setParent(init);
            queue.add(path);
            init = new Path();
            init.addLine(new Point(0,0),l.getPointB(),null);
            path = new Path(l.getPointB(),l.getPointA(),lines);
            path.setParent(init);
            queue.add(path);
        }

        int count = 0;
        Path curr = queue.peek();

        while( !curr.getToGo().isEmpty() ) {
            count++;
            //System.out.println(count++);
           // System.out.printf("Node expanded %d\n", count++);
            curr = queue.poll();

           // System.out.println("\nPopping G value "+curr.getG()+" "+curr.getLast().getPointA().getX()+" "+curr.getLast().getPointA().getY()+" to "+curr.getLast().getPointB().getX()+" "+curr.getLast().getPointB().getY() );
            //curr.printPath();
            for( Line l: curr.getToGo() ) {
                Path path = curr.duplicate();
                if( path.addLine(l.getPointA(), l.getPointB(), l ) ) {
                    path.setParent(curr);
                    queue.add(path);

               //     parent.put(curr,l);
                }
                path = curr.duplicate();
                if( path.addLine(l.getPointB(), l.getPointA(), l ) ) {
                    path.setParent(curr);
                    queue.add(path);
                }

            }
        }
        System.out.println(count+" nodes expanded");

        System.out.println("cost = "+Math.round(curr.getG() * 100.0) / 100.0);

        ArrayList<Point> finalPath = new ArrayList<Point>(1);
        while( curr.getParent() != null ) {
            finalPath.add(0,curr.getLast().getPointB());
            finalPath.add(0,curr.getLast().getPointA());
            curr = curr.getParent();
        }
        finalPath.add(0,new Point(0,0));

        Point last = new Point(0,0);
        boolean start = false;
        for( Point p: finalPath ) {
            if( !start ) {
                //System.out.printf("%d %d to %d %d\n", last.getX(), last.getY(), p.getX(), p.getY());
                last = new Point(p.getX(),p.getY());
                start = true;
            }



            else if( lines.contains(new Line(last,p)) ){
                if( !last.equals(p) ) {
                    System.out.printf("Draw from %d %d to %d %d\n", last.getX(), last.getY(), p.getX(), p.getY());
                    last = new Point(p.getX(),p.getY());
                }
            } else {
                if( !last.equals(p) ) {
                    System.out.printf("Move from %d %d to %d %d\n", last.getX(), last.getY(), p.getX(), p.getY());
                    last = new Point(p.getX(),p.getY());
                }
            }

        }



    }


    // result is the required output page.
    Page result;
    ArrayList<Line> lines;
    ArrayList<Point> allPoints;
    PriorityQueue<Path> queue;
}
