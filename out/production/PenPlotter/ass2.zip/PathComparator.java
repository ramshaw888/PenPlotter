import java.util.Comparator;

/**
 * Created by aaron on 10/05/2014.
 */
public class PathComparator implements Comparator<Path> {

    public PathComparator(){

    }

    @Override
    public int compare(Path a, Path b) {


        if( a.getG()+heuristic(a) < b.getG()+heuristic(b) ) {
            return -1;
        }

        if( a.getG()+heuristic(a) > b.getG()+heuristic(b) ) {
            return 1;
        }

        else {
            return 0;
        }

    }

    private double heuristic(Path path) {

        double x = 0.0;
        double y = 0.0;
        for( Line p: path.getToGo() ) {
            x+= p.getPointA().getX();
            x+= p.getPointB().getX();
            y+= p.getPointA().getY();
            y+= p.getPointB().getY();
        }

        x = x/(path.getToGo().size());
        y = y/(path.getToGo().size());

        double distFromCenterMass = path.distance(new Point((int) x,(int) y), path.getLast().getPointB() );


        return path.getToGo().size()-distFromCenterMass;
      //  return path.getToGo().size();
    }

}
