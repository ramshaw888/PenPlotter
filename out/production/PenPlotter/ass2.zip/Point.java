/**
 * Created by aaron on 7/05/2014.
 */
public class Point extends Object {

    public Point(int x,int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Point point = (Point) o;

        if (x != point.x) return false;
        if (y != point.y) return false;

        return true;
    }

    @Override
    public int hashCode() {

        int result = x;
        result = 31 * result + y;
        return result;
    }

    public double getDistance(Point p) {
        return  Math.sqrt( Math.pow(p.getX()-this.getX(), 2) + Math.pow( p.getY()-this.getY(), 2 ) );
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    private int x;
    private int y;
}
