import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;

/**
 * Created by aaron on 7/05/2014.
 */
public class Page {

    public Page() {
        this.path = new LinkedHashSet(1);
        move = 0.0;
    }

    public Page(Point a, Point b) {
        this.path = new LinkedHashSet(1);
        move = 0.0;
        addPoint(a,b);
    }

    public void addPoint(Point a, Point b) {
        path.add(a);
        path.add(b);
        lastPoint = b;
        move += Math.sqrt( Math.pow(b.getX()-a.getX(), 2) + Math.pow( b.getY()-a.getY(), 2 ) );
    }

    public Page duplicate() {
        Page newPage = new Page();
        newPage.setLastPoint(lastPoint);
        newPage.setMove(move);
        LinkedHashSet newPath = new LinkedHashSet(1);
        newPath.addAll(path);
        newPage.setPath(newPath);
        return newPage;
    }

    public Point getLastPoint() {
        return lastPoint;
    }

    public double getMove() {
        return move;
    }

    public void setPath(LinkedHashSet path) {
        this.path = path;
    }

    public void setLastPoint(Point lastPoint) {
        this.lastPoint = lastPoint;
    }

    public void setMove(double move) {
        this.move = move;
    }

    private LinkedHashSet path;
    private Point lastPoint;
    private double move;
}
